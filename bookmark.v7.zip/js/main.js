function refreshTime() {
    // get the current date time
    var currentDateTime = moment().tz("Europe/Paris");
    // update the date
    var currentDate = currentDateTime.format('D MMM YY');
    var displayDate = $("#date").html();
    if (currentDate != displayDate) { $("#date").html(currentDate); }
    // update the time
    var currentTime = currentDateTime.format('H:mm');
    $("#time").html(currentTime);
    // define the timeout interval
    var interval =  (60 - currentDateTime.second()) * 1000 - currentDateTime.millisecond();
    setTimeout(refreshTime, interval);
}

$(window).on('load', function(){

    // hack css animation
    $("body").removeClass("preload");

    // dashboard grid
    $(".dashboard .grid").masonry({
        columnWidth: '.grid-sizer',
        gutter: '.gutter-sizer',
        itemSelector: ".grid-item",
        percentPosition: true
    });

    // display current time
    refreshTime();

    $("#content .row.dashboard .card").on("click", function()
    {
        console.log("ok");
        $("#content .row.dashboard").addClass("transition").delay(600).queue(function(){
            $(this).hide().dequeue();
        });

        /*$(".grid").addClass("transition")*/

    })


});